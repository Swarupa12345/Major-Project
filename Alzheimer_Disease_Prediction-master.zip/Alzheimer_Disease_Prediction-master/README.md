# Alzheimer Disease Prediction (Time Series Classification)

This repository contains code for time series classification on Alzheimer's Disease Neuroimaging Initiative dataset. It is a "longitudinal" dataset and hence there are multiple visits per patients which results in multiple rows per patients.